import React from "react";

const Social = () => {
  return <div>Social</div>;
};

export default Social;
