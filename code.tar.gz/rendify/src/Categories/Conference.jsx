import React from "react";

const Conference = () => {
  return <div>Conference</div>;
};

export default Conference;
