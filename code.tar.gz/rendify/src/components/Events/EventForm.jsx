const EventForm = () => {
  return <div>EventForm</div>;
};

export default EventForm;
