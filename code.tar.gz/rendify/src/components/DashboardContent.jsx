import React from "react";

const DashboardContent = () => {
  return <div>DashboardContent</div>;
};

export default DashboardContent;
